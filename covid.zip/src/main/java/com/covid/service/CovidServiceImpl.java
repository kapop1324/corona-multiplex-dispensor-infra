package com.covid.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.covid.dao.CovidDAO;
import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;

@Service
public class CovidServiceImpl implements CovidService {
	
	@Inject
	private CovidDAO dao;	
	
	@Override
	public List<CovidVO> list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.list(hashmap);
	}

	

	@Override
	public void write(Map<String, String> hashmap) throws Exception {
		
		dao.write(hashmap);
	}


	@Override
	public UserVO login(LoginDTO dto) throws Exception {
		
		return dao.login(dto);
	}



	@Override
	public void create_user(UserVO vo) throws Exception {
		
		
		 dao.create_user(vo);
		
	}



	@Override
	public void enroll_building(CovidVO vo) throws Exception {
		
		dao.enroll_building(vo);
		
	}



	@Override
	public void enroll_store(CovidVO vo) throws Exception {

		dao.enroll_store(vo);
		
	}

	@Override
	public UserVO idcheck(String id) throws Exception {

		
			
		return  dao.idcheck(id);
	}



	@Override
	public List<CovidVO> dis() throws Exception {
		// TODO Auto-generated method stub
		return dao.dis();
	}



	@Override
	public List<CovidVO> district(String country) throws Exception {
		// TODO Auto-generated method stub
		return dao.district(country);
	}



	@Override
	public UserVO findid(LoginDTO dto) throws Exception {
		// TODO Auto-generated method stub
		return dao.findid(dto);
	}



	
	@Autowired
	JavaMailSender mailSender;
	
	@Override
	public void emailsend(String email,String password) throws Exception {
		
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(mimeMessage,true,"UTF-8");
		
		String title="임시비밀번호입니다.";
		String from = "rko3507@gmail.com";
		
		message.setFrom(from);
		message.setTo(email);
		message.setSubject(title);
		String content=
				 System.getProperty("line.separator")+ System.getProperty("line.separator")+
				 "발급된 비밀번호는"+password+"입니다."+ System.getProperty("line.separator")+
				  System.getProperty("line.separator");
		message.setText(content);
		mailSender.send(mimeMessage);
		
		
		/*
		 * MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {
		 * 
		 * @Override public void prepare(MimeMessage parammimeMessage) throws Exception
		 * { MimeMessageHelper message = new MimeMessageHelper(parammimeMessage, true,
		 * "UTF-8"); System.out.println(email); message.setTo(email);
		 * message.setFrom("寃⑥슱諛⑺븰"); message.setSubject("�엫�떆鍮꾨�踰덊샇"); ; message.setText(content,true);
		 * 
		 * }
		 * 
		 * };
		 */
		
		
		
       
		
	}


	
	@Override
	public void findpassword(Map<String, String> hashmap) throws Exception {
		
		
		
		dao.findpassword(hashmap);
		
	}



	@Override
	public List<CovidVO> building(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building(hashmap);
	}



	@Override
	public List<CovidVO> store(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.store(hashmap);
	}



	@Override
	public CovidVO addr(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.addr(hashmap);
	}



	@Override
	public int building_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building_count(hashmap);
	}



	@Override
	public void enroll_list(CovidVO vo) throws Exception {
		dao.enroll_list(vo);
		
	}



	@Override
	public CovidVO store_code(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.store_code(hashmap);
	}



	@Override
	public List<CovidVO> mystore(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.mystore(hashmap);
	}



	@Override
	public int store_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.store_count(hashmap);
	}



	@Override
	public List<CovidVO> list_manager_list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.list_manager_list(hashmap);
	}



	@Override
	public int list_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.list_count(hashmap);
	}



	@Override
	public int list_check_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.list_check_count(hashmap);
	}

	
	@Override
	public List<CovidVO> list_manager_check(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.list_manager_check(hashmap);
	}



	@Override
	public int check_all_count() throws Exception {
		// TODO Auto-generated method stub
		return dao.check_all_count();
	}



	@Override
	public int check_today_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.check_today_count(hashmap);
	}



	@Override
	public int building_all_count() throws Exception {
		// TODO Auto-generated method stub
		return dao.building_all_count();
	}



	@Override
	public int store_all_count() throws Exception {
		// TODO Auto-generated method stub
		return dao.store_all_count();
	}



	@Override
	public List<CovidVO> check_store_list() throws Exception {
		// TODO Auto-generated method stub
		return dao.check_store_list();
	}



	@Override
	public List<CovidVO> korea_map_building(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.korea_map_building(hashmap);
	}



	@Override
	public List<CovidVO> korea_map_building_list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.korea_map_building_list(hashmap);
	}



	@Override
	public List<CovidVO> status(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.status(hashmap);
	}



	@Override
	public CovidVO building_map(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building_map(hashmap);
	}



	@Override
	public List<CovidVO> building_main_list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building_main_list(hashmap);
	}



	@Override
	public List<CovidVO> building_main_graph(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building_main_graph(hashmap);
	}



	@Override
	public List<CovidVO> building_donut_graph(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.building_donut_graph(hashmap);
	}



	@Override
	public int check_today_good_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.check_today_good_count(hashmap);
	}



	@Override
	public int check_today_error_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return dao.check_today_error_count(hashmap);
	}



	@Override
	public void newpassword(UserVO vo) throws Exception {
		
		dao.newpassword(vo);
		
	}





      
    
	
}
