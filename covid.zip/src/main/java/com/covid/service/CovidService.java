package com.covid.service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;

public interface CovidService {
	
	public List<CovidVO> list(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> list_manager_list(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> building_main_list(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> building_main_graph(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> building_donut_graph(Map<String, String> hashmap) throws Exception;
	
	public CovidVO building_map(Map hashmap) throws Exception;
	
	public List<CovidVO> list_manager_check(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> store(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> korea_map_building(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> korea_map_building_list(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> status(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> mystore(Map<String, String> hashmap) throws Exception;
	
	public List<CovidVO> building(Map hashmap) throws Exception;
	
	public CovidVO addr(Map<String, String> hashmap) throws Exception;
	
	public CovidVO store_code(Map<String, String> hashmap) throws Exception;
	
	public void write(Map<String, String> hashmap) throws Exception;
	
	UserVO login(LoginDTO dto) throws Exception;
	
	public void create_user(UserVO vo) throws Exception;
	
	public void enroll_building(CovidVO vo) throws Exception;
	
	public void enroll_list(CovidVO vo) throws Exception;
	
	public void enroll_store(CovidVO vo) throws Exception;
	
	//아이디 체크
	public UserVO idcheck(String id) throws Exception;
	
	
	public List<CovidVO> dis() throws Exception;
	
	public List<CovidVO> district(String country) throws Exception;
	
	UserVO findid(LoginDTO dto) throws Exception;
	
	//이메일보내기
	public void emailsend(String email,String password) throws Exception;
	//비밀번호찾기
	public void findpassword(Map<String, String> hashmap) throws Exception;
	
	public int building_count(Map hashmap) throws Exception;
	
	public int store_count(Map hashmap) throws Exception;
	
	public int list_count(Map hashmap) throws Exception;
	
	public int list_check_count(Map hashmap) throws Exception;
	
	
	//대문
	public int check_all_count() throws Exception;
	
	public int check_today_count(Map hashmap) throws Exception;
	
	public int check_today_good_count(Map hashmap) throws Exception;
	
	public int check_today_error_count(Map hashmap) throws Exception;
	
	public int building_all_count() throws Exception;
	
	public int store_all_count() throws Exception;
	
	public List<CovidVO> check_store_list() throws Exception;
	
	
	public void newpassword(UserVO vo) throws Exception;
	
}
