package com.covid.dao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;

@Repository
public class CovidDAOImpl implements CovidDAO {
	
	@Inject
	private SqlSession sql;
	
	private static String namespace = "com.covid.mappers.covid";
	
	@Override
	public List<CovidVO> list(Map<String, String> hashmap) throws Exception {
		
		return sql.selectList(namespace+ ".list",hashmap);
	}

	@Override
	public void write(Map<String, String> hashmap) throws Exception {
		
		sql.insert(namespace+".write",hashmap);
	}

	@Override
	public UserVO login(LoginDTO dto) throws Exception {
	
		return sql.selectOne(namespace+".login",dto);
	}

	@Override
	public void create_user(UserVO vo) throws Exception {
		
		 sql.insert(namespace+".create_user", vo);
		
	}

	@Override
	public void enroll_building(CovidVO vo) throws Exception {
		
		sql.insert(namespace+".enroll_building",vo);
		
	}

	@Override
	public void enroll_store(CovidVO vo) throws Exception {
		
		sql.insert(namespace+".enroll_store",vo);
		
	}

	@Override
	public UserVO idcheck(String id) throws Exception {
		
	
		return sql.selectOne(namespace+".idcheck",id); 
	}

	@Override
	public List<CovidVO> check(String num) throws Exception {
	
		return sql.selectList(namespace+ ".check",num);
	}

	@Override
	public List<CovidVO> dis() throws Exception {
		
		return sql.selectList(namespace+ ".dis");
	}

	@Override
	public List<CovidVO> district(String country) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+ ".district",country);
	}

	@Override
	public UserVO findid(LoginDTO dto) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".findid",dto);
	}

	@Override
	public void findpassword(Map<String, String> hashmap) throws Exception {
		
		
		
		sql.update(namespace+".findpassword",hashmap);
		
	}

	@Override
	public List<CovidVO> building(Map hashmap) throws Exception {
		
		return sql.selectList(namespace+".building",hashmap);
	}

	@Override
	public List<CovidVO> store(Map<String, String> hashmap) throws Exception {
		
		return sql.selectList(namespace+".store",hashmap);
	}

	@Override
	public CovidVO addr(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+ ".addr",hashmap);
	}

	@Override
	public int building_count(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace + ".building_count",hashmap);
	}

	@Override
	public void enroll_list(CovidVO vo) throws Exception {
		 
		sql.insert(namespace+".enroll_list", vo);
		
	}

	@Override
	public CovidVO store_code(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".code_check",hashmap);
	}

	@Override
	public List<CovidVO> mystore(Map hashmap) throws Exception {

		return sql.selectList(namespace+".mystore",hashmap);
	}

	@Override
	public int store_count(Map hashmap) throws Exception {

		return sql.selectOne(namespace + ".store_count",hashmap);
	}

	@Override
	public List<CovidVO> list_manager_list(Map<String, String> hashmap) throws Exception {
	
		return sql.selectList(namespace+".list_manager_list",hashmap);
	}

	@Override
	public int list_count(Map hashmap) throws Exception {
	
		return sql.selectOne(namespace+".list_count",hashmap);
	}
	
	@Override
	public int list_check_count(Map hashmap) throws Exception {
		
		return sql.selectOne(namespace+".list_check_count",hashmap);
	}
	
	@Override
	public List<CovidVO> list_manager_check(Map<String, String> hashmap) throws Exception {
	
		return sql.selectList(namespace+".list_manager_check",hashmap);
	}

	@Override
	public int check_all_count() throws Exception {
	
		return sql.selectOne(namespace+".check_all_count");
	}
	
	@Override
	public int check_today_count(Map hashmap) throws Exception {
	
		return sql.selectOne(namespace+".check_today_count",hashmap);
	}
	
	@Override
	public int check_today_good_count(Map hashmap) throws Exception {
	
		return sql.selectOne(namespace+".check_today_good_count",hashmap);
	}
	
	@Override
	public int check_today_error_count(Map hashmap) throws Exception {
	
		return sql.selectOne(namespace+".check_today_error_count",hashmap);
	}

	@Override
	public int building_all_count() throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".building_all_count");
	}
	
	@Override
	public int store_all_count() throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".store_all_count");
	}
	
	@Override
	public List<CovidVO> check_store_list() throws Exception {
	
		return sql.selectList(namespace+ ".check_store_list");
	}

	@Override
	public List<CovidVO> korea_map_building(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".korea_map_building",hashmap);
	}
	
	@Override
	public List<CovidVO> korea_map_building_list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".korea_map_building_list",hashmap);
	}

	@Override
	public List<CovidVO> status(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".status",hashmap);
	}

	@Override
	public CovidVO building_map(Map hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".building_map",hashmap);
	}

	@Override
	public List<CovidVO> building_main_list(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".building_main_list",hashmap);
	}

	@Override
	public List<CovidVO> building_main_graph(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".building_main_graph",hashmap);
	}

	@Override
	public List<CovidVO> building_donut_graph(Map<String, String> hashmap) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".building_donut_graph",hashmap);
	}

	@Override
	public void newpassword(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		sql.update(namespace+".newpassword",vo);
	}
}
