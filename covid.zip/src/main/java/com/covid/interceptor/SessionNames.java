package com.covid.interceptor;

public interface SessionNames {
	static final String LOGIN = "loginUser";
	static final String LOGIN_COOKIE = "loginCookie";
	static final String ATTEMPTED = "attemptedLocation";
}
