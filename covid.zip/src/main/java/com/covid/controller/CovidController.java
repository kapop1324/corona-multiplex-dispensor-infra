package com.covid.controller;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.WebUtils;

import com.covid.interceptor.SessionNames;
import com.covid.dao.CovidDAO;
import com.covid.domain.ApiDTO;
import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;
import com.covid.service.CovidService;
import com.covid.service.CovidServiceImpl;

@Controller
@RequestMapping("/covid/*")
public class CovidController implements SessionNames {
	
	@Autowired
	BCryptPasswordEncoder passEncoder;


	
	@Inject
	CovidService service;
	
	@Inject
	private SqlSession sql;
	
	private static String namespace = "com.covid.mappers.covid";
	
	
	@RequestMapping(value="/korea_map", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuildingfind(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		String district_num = map.get("district_num");
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("district_num", district_num);
		
		
		
		
		List<CovidVO> korea_map_building = null;
		korea_map_building = service.korea_map_building(hashmap);
		
		model.addAttribute("korea_map_building",korea_map_building);
		
		return korea_map_building;
		
	}
	
	@RequestMapping(value="/building_list", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuildinglist(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		String district = map.get("district");
		String city = map.get("city");
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("district", district);
		hashmap.put("city", city);  
		 
		
		List<CovidVO> korea_map_building_list = null;
		korea_map_building_list = service.korea_map_building_list(hashmap);
		 
		model.addAttribute("korea_map_building_list",korea_map_building_list);
		 
		return korea_map_building_list;
		  
	}
	
	@RequestMapping(value="/check", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postchecklists(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		
		String bno = map.get("bno");
		 
		System.out.println(bno);
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		 
		
		 
		
		List<CovidVO> status = null;
		status = service.status(hashmap);
		 
		model.addAttribute("status",status);
		 
		return status;
		  
	}
	
	@RequestMapping(value="/map", method = RequestMethod.POST)
	@ResponseBody
	public  CovidVO postmap(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		
		String bno = map.get("bno");
		System.out.println(bno);
		
		Map hashmap = new HashMap();
		hashmap.put("bno", Integer.parseInt(bno));
		
		
		
		CovidVO building_map = null;
		building_map = service.building_map(hashmap);
		 
		model.addAttribute("building_map",building_map);
		
		if(building_map == null) {
			System.out.println("d");
		}
		 
		
		return building_map;
		  
	}
	
	@RequestMapping(value="/building_main_list", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuilding_main_list(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		

		String bno = map.get("bno");
		 
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		 
		
		 
		
		List<CovidVO> building_main_list = null;
		building_main_list = service.building_main_list(hashmap);
		 
		model.addAttribute("building_main_list",building_main_list);
		 
		return building_main_list;
		  
	}
	
	@RequestMapping(value="/building_main_graph", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuilding_main_graph(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		  

		String bno = map.get("bno");
		 
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		 
		 
		 
		
		List<CovidVO> building_main_graph = null;
		building_main_graph = service.building_main_graph(hashmap);
		 
		model.addAttribute("building_main_graph",building_main_graph);
		 
		return building_main_graph;
		  
	}
	
	
	@RequestMapping(value="/building_donut_graph", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuilding_donut_graph(Model model,@RequestParam Map<String, String> map) throws Exception{
		 
		

		String bno = map.get("bno");
		 
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		 
		
		 
		
		List<CovidVO> building_donut_graph = null;
		building_donut_graph = service.building_donut_graph(hashmap);
		 
		model.addAttribute("building_main_graph",building_donut_graph);
		 
		return building_donut_graph;
		  
	}
	
	@RequestMapping(value="/list", method = RequestMethod.GET)
	public void getList(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String country = parammap.get("country_search");
		String district = parammap.get("district_search");
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("country", country);
		hashmap.put("district", district);
		
		List<CovidVO> list = null;
		list = service.list(hashmap);
		
		model.addAttribute("list",list);
		
		List<CovidVO> dis = null;
		dis = service.dis();
		
		model.addAttribute("dis",dis);
		
		
	}
	
	
	
	@RequestMapping(value="/write", method = RequestMethod.GET)
	public void gettWrite(@RequestParam Map <String, String> parammap) throws Exception{
		
		String temp = parammap.get("temp");
		String count = parammap.get("count");
		String sanCount = parammap.get("sanCount");
		String building_num = parammap.get("building_num");
		String store_num = parammap.get("store_num");
		
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("temp", temp);
		hashmap.put("count", count);
		hashmap.put("sanCount", sanCount);
		hashmap.put("building_num", building_num);
		hashmap.put("store_num", store_num);
		
		
		service.write(hashmap);
		
	
	}
	
	
	
		
	
	
	
	
	//嫄대Ъ�벑濡�
	@RequestMapping(value="/enroll_building", method = RequestMethod.GET)
	public void getEnroll_building() {
		
	}
	
	@RequestMapping(value="/enroll_building", method = RequestMethod.POST)
	public String postEnroll_building(CovidVO vo,UserVO vo2,@RequestParam("id") String id) throws Exception {
		
		
		
		vo.setId(id);
		
		service.enroll_building(vo);
		System.out.println(id);
		
		return "redirect:/covid/mybuilding?id="+vo.getId()+"&num=1&num2=1";
	}
	
	//�긽媛��벑濡�
	@RequestMapping(value="/enroll_store", method = RequestMethod.GET)
	public void getEnroll_store(Model model,@RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("id", id);
		  
		
		List<CovidVO> building = null;
		building = service.building(hashmap);
		
		model.addAttribute("building",building);
		
	} 
	
	@RequestMapping(value="/enroll_store", method = RequestMethod.POST)
	public String postEnroll_store(CovidVO vo,@RequestParam Map <String, String> parammap) throws Exception {
		
		String id = parammap.get("id");
		  
		vo.setId(id); 
		
		service.enroll_store(vo); 
		
		return "redirect:/covid/mybuilding?&num=1&num2=1&id="+vo.getId();
	}
	
	@RequestMapping(value="/map1", method = RequestMethod.GET)
	public void getMap(Model model, @RequestParam Map <String, String> parammap) throws Exception{
		
		String bno = parammap.get("bno");
		
		Map<String, String> hashmap = new HashMap<String, String>();
		
		hashmap.put("bno", bno);
		
		
		
		CovidVO addr = null;
		addr = service.addr(hashmap);
		
		model.addAttribute("addr",addr);
	}
	
	
	
	
	@RequestMapping(value="/graph", method = RequestMethod.GET)
	public void getgraph() throws Exception {
			
	}
	
	@RequestMapping(value="/district", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postdistrict(Model model,@RequestParam Map<String, String> map) throws Exception{
		
		String country = map.get("country");
		List<CovidVO> district = null;
		district = service.district(country);
	
		model.addAttribute("district",district);
		
		
		
		
		
		return district;
		
	}
	

	
	
	

	
	@RequestMapping(value="/mypage", method = RequestMethod.GET)
	public void getmypage() throws Exception {
		
		
		
		
			
	}
	
	@RequestMapping(value="/mypage_store", method = RequestMethod.GET)
	public void getmypagestore() throws Exception {
		
		
		
		
			
	}
	
	@RequestMapping(value="/mybuilding", method = RequestMethod.GET)
	public void getmybuilding(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		Map hashmap = new HashMap();
		
		String id = parammap.get("id");
		
		
		
		hashmap.put("id", id);
		
	
			int num = Integer.parseInt(parammap.get("num"));
			
			int count = service.building_count(hashmap);
			
			int postNum = 5;
			
			int pageNum = (int)Math.ceil((double)count/postNum);
			
			int displayPost = (num - 1) * postNum;
			 
			int pageNum_cnt = 10;
			
			int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
			
			int startPageNum = endPageNum - (pageNum_cnt - 1);
			
			int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
			 
			if(endPageNum > endPageNum_tmp) {
			 endPageNum = endPageNum_tmp;
			}
			
			boolean prev = startPageNum == 1 ? false : true;
			boolean next = endPageNum * pageNum_cnt >= count ? false : true;
			
			hashmap.put("displayPost", displayPost);
			
			hashmap.put("postNum", postNum);
			
			List<CovidVO> building = service.building(hashmap);
			
			
			model.addAttribute("building",building);
			
			model.addAttribute("pageNum", pageNum);
			
			model.addAttribute("startPageNum", startPageNum);
			
			model.addAttribute("endPageNum", endPageNum);

			model.addAttribute("prev", prev);
			
			model.addAttribute("next", next);
			
			model.addAttribute("select",num);
			
			
			int num2 = Integer.parseInt(parammap.get("num2"));
			
			int count2 = service.store_count(hashmap);
			
			int postNum2 = 5;
			
			int pageNum2 = (int)Math.ceil((double)count2/postNum2);
			
			int displayPost2 = (num2 - 1) * postNum2;
			
			int pageNum_cnt2 = 10;
			
			int endPageNum2 = (int)(Math.ceil((double)num2 /(double)pageNum_cnt2) * pageNum_cnt2);
			
			int startPageNum2 = endPageNum2 - (pageNum_cnt2 - 1);
			
			int endPageNum_tmp2 = (int)(Math.ceil((double)count2 / (double)pageNum_cnt2));
			 
			if(endPageNum2 > endPageNum_tmp2) {
			 endPageNum2 = endPageNum_tmp2;
			}
			
			boolean prev2 = startPageNum2 == 1 ? false : true;
			boolean next2 = endPageNum2 * pageNum_cnt2 >= count2 ? false : true;
			
			hashmap.put("displayPost2", displayPost2);
			
			hashmap.put("postNum2", postNum2);
			
			List<CovidVO> store = service.mystore(hashmap);
			
			
			model.addAttribute("store",store);
			
			model.addAttribute("pageNum2", pageNum2);
			
			model.addAttribute("startPageNum2", startPageNum2);
			
			model.addAttribute("endPageNum2", endPageNum2);

			model.addAttribute("prev2", prev2);
			
			model.addAttribute("next2", next2);
			
			model.addAttribute("select2",num2);
		
		 
 
		
		 
			
	}
	
	@RequestMapping(value="/mybuilding_store", method = RequestMethod.GET)
	public void getmybuildingstore(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		Map hashmap = new HashMap();
		
		String id = parammap.get("id");
		
		
		
		hashmap.put("manager_id", id);
		
	
			
			
			int num2 = Integer.parseInt(parammap.get("num2"));
			
			int count2 = service.store_count(hashmap);
			
			int postNum2 = 5;
			
			int pageNum2 = (int)Math.ceil((double)count2/postNum2);
			
			int displayPost2 = (num2 - 1) * postNum2;
			
			int pageNum_cnt2 = 10;
			
			int endPageNum2 = (int)(Math.ceil((double)num2 /(double)pageNum_cnt2) * pageNum_cnt2);
			
			int startPageNum2 = endPageNum2 - (pageNum_cnt2 - 1);
			
			int endPageNum_tmp2 = (int)(Math.ceil((double)count2 / (double)pageNum_cnt2));
			 
			if(endPageNum2 > endPageNum_tmp2) {
			 endPageNum2 = endPageNum_tmp2;
			}
			
			boolean prev2 = startPageNum2 == 1 ? false : true;
			boolean next2 = endPageNum2 * pageNum_cnt2 >= count2 ? false : true;
			
			hashmap.put("displayPost2", displayPost2);
			
			hashmap.put("postNum2", postNum2);
			
			List<CovidVO> store = service.mystore(hashmap);
			
			
			model.addAttribute("store",store);
			
			model.addAttribute("pageNum2", pageNum2);
			
			model.addAttribute("startPageNum2", startPageNum2);
			
			model.addAttribute("endPageNum2", endPageNum2);

			model.addAttribute("prev2", prev2);
			
			model.addAttribute("next2", next2);
			
			model.addAttribute("select2",num2);
		
		

		
		
			
	}
	
	
	@RequestMapping(value="/mystore", method = RequestMethod.GET)
	public void getmystore(Model model,@RequestParam Map <String, String> parammap) throws Exception {
		
		String building_bno = parammap.get("bno");
		
		
		 
		Map hashmap = new HashMap<String, String>();
		
		hashmap.put("building_bno", building_bno);
		
	
		
		List<CovidVO> store = service.store(hashmap);
	
		model.addAttribute("store",store);
		
		
	}
	

	
	private String UPLOAD_PATH = "C:\\Users\\user\\eclipse-workspace\\covid\\src\\main\\webapp\\resources\\photo";
	
	private String saveFile(MultipartFile file) {
		
	
		String saveName = file.getOriginalFilename();
		String filename = file.getOriginalFilename();
		
		
		
		File saveFile = new File(UPLOAD_PATH,saveName);
		
		try {
			file.transferTo(saveFile);
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
		}
		
		return saveName;
		
		
	}
	
	
	@RequestMapping(value="/file_upload", method = RequestMethod.GET)
	public void getfileupload(MultipartFile[] uploadfiles,Model model) throws Exception {
		
		
	
		
		
		
		
		
	}
	
	@RequestMapping(value = "file_upload", method = RequestMethod.POST)
	public void multipleuploadpost(MultipartFile[] uploadfiles,Model model) throws Exception{
		
		
		String result = "";
		for(MultipartFile f : uploadfiles) {
			result += saveFile(f);
		}
		
		model.addAttribute("result",result);
		
		 
	}
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public void getproduct() throws Exception{
		
	}
	
	@RequestMapping(value = "/manual", method = RequestMethod.GET)
	public void getmanual() throws Exception{
		
	}
	@RequestMapping(value = "/manual_dispensor", method = RequestMethod.GET)
	public void getmanualdispensor() throws Exception{
		
	}
	@RequestMapping(value = "/buy", method = RequestMethod.GET)
	public void getbuy() throws Exception{
		
	}
	
	@RequestMapping(value = "/faq", method = RequestMethod.GET)
	public void getfaq() throws Exception{
		
	}
	
	@RequestMapping(value = "/as", method = RequestMethod.GET)
	public void getas() throws Exception{
		
	}
	
	@RequestMapping(value = "/terms", method = RequestMethod.GET)
	public void getterms() throws Exception{
		
	}
	
}
