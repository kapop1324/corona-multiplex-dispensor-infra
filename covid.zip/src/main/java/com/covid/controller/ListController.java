package com.covid.controller;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.WebUtils;

import com.covid.interceptor.SessionNames;
import com.covid.dao.CovidDAO;
import com.covid.domain.ApiDTO;
import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;
import com.covid.service.CovidService;
import com.covid.service.CovidServiceImpl;

@Controller
@RequestMapping("/covid/*")
public class ListController implements SessionNames {
	
	@Autowired
	BCryptPasswordEncoder passEncoder;


	
	@Inject
	CovidService service;
	
	@Inject
	private SqlSession sql;
	
	private static String namespace = "com.covid.mappers.covid";
	
	
	
	
	
	
	

	
	

	
	

	//전자출입명부 메인화면
	@RequestMapping(value="/list_main", method = RequestMethod.GET)
	public void getlistmain() throws Exception {
		
	
		
		
	}
	
	//전자출입명부 방문자용 대문
	@RequestMapping(value="/list_customer", method = RequestMethod.GET)
	public void getlistcustomer( ) throws Exception {

	}
	
	//전자출입명부 방문자용 작성
	@RequestMapping(value="/list_customer", method = RequestMethod.POST)
	public String postlistcustomer(CovidVO vo) throws Exception {
		

			String phonenumber = vo.getPhone_number();
			String phone = passEncoder.encode(phonenumber);
			vo.setPhone_number(phone);;
			service.enroll_list(vo);
			
		
		return "redirect:/covid/list_main";
	}
	
	//전자출입명부 관리자 점주용 대문
	@RequestMapping(value="/list_manager", method = RequestMethod.GET)
	public void getlistmanager(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
	
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("id", id);
		
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		
		
		
		
	}
	//빌딩 번호 점포번호 알아오기
	@RequestMapping(value="/code_check", method = RequestMethod.POST)
	public @ResponseBody CovidVO postcodechek(Model model, @RequestParam Map <String, String> parammap) throws Exception{
		
		
		String bno = parammap.get("bno");
			
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		
		
		CovidVO store_code = null;
		store_code = service.store_code(hashmap);
		
		model.addAttribute("store_code",store_code);
		
		
		return store_code;
		
	}
	
	
	//전자출입명부 관리자 점주용 방문기록
	@RequestMapping(value="/list_manager_list", method = RequestMethod.GET)
	public void getlistmanagerlist(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		
		int num = Integer.parseInt(num1);
		
		int count = service.list_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_list(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		
		
		
	}
	
	//전자출입명부 관리자 점주용 방문기록 검색
	@RequestMapping(value="/list_manager_search", method = RequestMethod.GET)
	public void getlistmanagersearch(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		String bno = parammap.get("bno");
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		hashmap.put("bno", bno);
		int num = Integer.parseInt(num1);
		
		int count = service.list_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		List<CovidVO> building = service.building(hashmap);
		
		model.addAttribute("building",building);
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_list(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		
		
		
	}
	
	//전자출입명부 관리자 점주용 방문기록 재검색 
	@RequestMapping(value="/list_check", method = RequestMethod.POST)
	public @ResponseBody List<CovidVO> postlistchek(Model model, @RequestParam Map <String, String> parammap) throws Exception{
	
		String bno = parammap.get("bno");
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		
		
		List<CovidVO> newlist = null;
		newlist = service.list_manager_list(hashmap);
		
		model.addAttribute("newlist",newlist);
		
		
		return newlist;
		
	}
	
	//전자출입명부 관리자 점주용 검사기록
	@RequestMapping(value="/list_manager_check", method = RequestMethod.GET)
	public void getlistmanagercheck(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		
		int num = Integer.parseInt(num1);
		
		int count = service.list_check_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_check(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		
		
		
	}
	
	//전자출입명부 관리자 점주용 검사기록 검색
	@RequestMapping(value="/list_manager_check_search", method = RequestMethod.GET)
	public void getlistmanagerchecksearch(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		String bno = parammap.get("bno");
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		hashmap.put("bno", bno);
		int num = Integer.parseInt(num1);
		
		int count = service.list_check_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		List<CovidVO> building = service.building(hashmap);
		
		model.addAttribute("building",building);
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_check(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		
		
		
	}
	
	//전자출입명부 관리자 점주용 검사기록 재검색
	@RequestMapping(value="/list_check_board", method = RequestMethod.POST)
	public @ResponseBody List<CovidVO> postlistchek1(Model model, @RequestParam Map <String, String> parammap) throws Exception{
	
		String bno = parammap.get("bno");
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bno", bno);
		
		
		List<CovidVO> newlist = null;
		newlist = service.list_manager_check(hashmap);
		
		model.addAttribute("newlist",newlist);
		
		
		return newlist;
		
	}
	
	//전자출입명부 관리자 건물주용 대문
		@RequestMapping(value="/list_master", method = RequestMethod.GET)
		public void getlistmaster(Model model, @RequestParam Map <String, String> parammap) throws Exception {
			
			
			String id = parammap.get("id");
		
			
			Map<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("id", id);
			
			
			List<CovidVO> building = service.building(hashmap);
			
			model.addAttribute("building",building);
			
			
			
			
			
			
		}
	
	//전자출입명부 관리자 건물주용 방문기록
	@RequestMapping(value="/list_master_list", method = RequestMethod.GET)
	public void getlistmasterlist(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		String master= "master";
	
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		hashmap.put("master", master);
		int num = Integer.parseInt(num1);
		
		int count = service.list_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		List<CovidVO> building = service.building(hashmap);
		
		model.addAttribute("building",building);
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_list(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		System.out.println(displayPost);
		
		
	}
	
	//전자출입명부 관리자 건물주용 빌딩검색
	@RequestMapping(value="/list_building_find", method = RequestMethod.POST)
	@ResponseBody
	public  List<CovidVO> postbuildingfind(Model model,@RequestParam Map<String, String> map) throws Exception{
		
		String building_number = map.get("building_num");
		
		Map<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("building_number", building_number);
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		 
		return store;
		
	}
	
	//전자출입명부 관리자 건물주용 방문기록 검색
	@RequestMapping(value="/list_master_search", method = RequestMethod.GET)
	public void getlistmastersearch(Model model, @RequestParam Map <String, String> parammap) throws Exception {
		
		
		String id = parammap.get("id");
		String num1 = parammap.get("num");
		String bno = parammap.get("bno");
		String master= "master";
		
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		hashmap.put("bno", bno);
		hashmap.put("master", master);
		int num = Integer.parseInt(num1);
		
		int count = service.list_count(hashmap);
		
		int postNum = 10;
		
		int pageNum = (int)Math.ceil((double)count/postNum);
		
		int displayPost = (num - 1) * postNum;
		
		int pageNum_cnt = 10;
		
		int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
		
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		hashmap.put("displayPost", displayPost);
		
		hashmap.put("postNum", postNum);
		
		
		
		model.addAttribute("pageNum", pageNum);
		
		model.addAttribute("startPageNum", startPageNum);
		
		model.addAttribute("endPageNum", endPageNum);

		model.addAttribute("prev", prev);
		
		model.addAttribute("next", next);
		
		model.addAttribute("select",num);
		
		List<CovidVO> building = service.building(hashmap);
		
		model.addAttribute("building",building);
		
		List<CovidVO> store = null;
		store = service.store(hashmap);
		
		model.addAttribute("store",store);
		
		
		List<CovidVO> store_list = null;
		store_list = service.list_manager_list(hashmap);
		
		model.addAttribute("store_list",store_list);
		
		
		
		
	}
	

	
	
	//전자출입명부 관리자 건물주용 검사기록
		@RequestMapping(value="/list_master_check", method = RequestMethod.GET)
		public void getlistmastercheck(Model model, @RequestParam Map <String, String> parammap) throws Exception {
			
			
			String id = parammap.get("id");
			String num1 = parammap.get("num");
			String master= "master";
		
			Map hashmap = new HashMap();
			hashmap.put("id", id);
			hashmap.put("master", master);
			int num = Integer.parseInt(num1);
			
			int count = service.list_check_count(hashmap);
			
			int postNum = 10;
			
			int pageNum = (int)Math.ceil((double)count/postNum);
			
			int displayPost = (num - 1) * postNum;
			
			int pageNum_cnt = 10;
			
			int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
			
			int startPageNum = endPageNum - (pageNum_cnt - 1);
			
			int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
			 
			if(endPageNum > endPageNum_tmp) {
			 endPageNum = endPageNum_tmp;
			}
			
			boolean prev = startPageNum == 1 ? false : true;
			boolean next = endPageNum * pageNum_cnt >= count ? false : true;
			
			hashmap.put("displayPost", displayPost);
			
			hashmap.put("postNum", postNum);
			
			
			
			model.addAttribute("pageNum", pageNum);
			
			model.addAttribute("startPageNum", startPageNum);
			
			model.addAttribute("endPageNum", endPageNum);

			model.addAttribute("prev", prev);
			
			model.addAttribute("next", next);
			
			model.addAttribute("select",num);
			
			List<CovidVO> building = service.building(hashmap);
			
			model.addAttribute("building",building);
			
			List<CovidVO> store = null;
			store = service.store(hashmap);
			
			model.addAttribute("store",store);
			
			
			List<CovidVO> store_list = null;
			store_list = service.list_manager_check(hashmap);
			
			model.addAttribute("store_list",store_list);
			
			System.out.println(displayPost);
			
			
		}
	
		//전자출입명부 관리자 건물주용 검사기록 재검색
		@RequestMapping(value="/list_master_check_search", method = RequestMethod.GET)
		public void getlistmasterchecksearch(Model model, @RequestParam Map <String, String> parammap) throws Exception {
			
			
			String id = parammap.get("id");
			String num1 = parammap.get("num");
			String bno = parammap.get("bno");
			String master= "master";
			
			Map hashmap = new HashMap();
			hashmap.put("id", id);
			hashmap.put("bno", bno);
			hashmap.put("master", master);
			int num = Integer.parseInt(num1);
			
			int count = service.list_check_count(hashmap);
			
			int postNum = 10;
			
			int pageNum = (int)Math.ceil((double)count/postNum);
			
			int displayPost = (num - 1) * postNum;
			
			int pageNum_cnt = 10;
			
			int endPageNum = (int)(Math.ceil((double)num /(double)pageNum_cnt) * pageNum_cnt);
			
			int startPageNum = endPageNum - (pageNum_cnt - 1);
			
			int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
			 
			if(endPageNum > endPageNum_tmp) {
			 endPageNum = endPageNum_tmp;
			}
			
			boolean prev = startPageNum == 1 ? false : true;
			boolean next = endPageNum * pageNum_cnt >= count ? false : true;
			
			hashmap.put("displayPost", displayPost);
			
			hashmap.put("postNum", postNum);
			
			
			
			model.addAttribute("pageNum", pageNum);
			
			model.addAttribute("startPageNum", startPageNum);
			
			model.addAttribute("endPageNum", endPageNum);

			model.addAttribute("prev", prev);
			
			model.addAttribute("next", next);
			
			model.addAttribute("select",num);
			
			List<CovidVO> building = service.building(hashmap);
			
			model.addAttribute("building",building);
			
			List<CovidVO> store = null;
			store = service.store(hashmap);
			
			model.addAttribute("store",store);
			
			
			List<CovidVO> store_list = null;
			store_list = service.list_manager_check(hashmap);
			
			model.addAttribute("store_list",store_list);
			
			
			
			
		}
		
	
	
	
	
	
}
