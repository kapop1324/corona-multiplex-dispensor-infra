package com.covid.controller;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.WebUtils;

import com.covid.interceptor.SessionNames;
import com.covid.dao.CovidDAO;
import com.covid.domain.ApiDTO;
import com.covid.domain.CovidVO;
import com.covid.domain.LoginDTO;
import com.covid.domain.UserVO;
import com.covid.service.CovidService;
import com.covid.service.CovidServiceImpl;

@Controller
@RequestMapping("/covid/*")
public class UserController implements SessionNames {
	
	@Autowired
	BCryptPasswordEncoder passEncoder;


	
	@Inject
	CovidService service;
	
	@Inject
	private SqlSession sql;
	
	private static String namespace = "com.covid.mappers.covid";
	
	
	
	
	//濡쒓렇�씤
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public void getLogin() throws Exception {
		
	}
	
	@RequestMapping(value="/loginPost", method = RequestMethod.POST)
	public void loginPost(LoginDTO dto,HttpSession session, Model model) throws Exception{
		
		try {
			
			UserVO user = service.login(dto);
			
			boolean passMatch = passEncoder.matches(dto.getPw(), user.getPw());
			
			if(user != null && passMatch) {
				model.addAttribute("user",user);
			
			}
			else {
				UserVO fail = service.login(dto);
				model.addAttribute("fail",fail);
			
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	
		
	}
	
	//濡쒓렇�븘�썐
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public void logout(HttpSession session,HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		
		String attempted = (String)session.getAttribute(ATTEMPTED);

		
		if(attempted == null) {
			response.sendRedirect("/covid/login");
		}else {
			response.sendRedirect(attempted);
			
		}
		
		
		
		session.removeAttribute(SessionNames.LOGIN);
		session.invalidate();
		
		Cookie loginCookie = WebUtils.getCookie(request,SessionNames.LOGIN);
		if(loginCookie != null) {
			loginCookie.setPath("/");
			loginCookie.setMaxAge(0);
			
			response.addCookie(loginCookie);

			
			 

		}
		
	
		
	}
	
	//�쉶�썝媛��엯
	@RequestMapping(value="/create_user", method = RequestMethod.GET)
	public void getCreate_user(HttpServletRequest request) {
		String old_url = (String)request.getHeader("REFERER");
	}
	
	@RequestMapping(value="/create_user", method = RequestMethod.POST)
	public String postCreate_user(UserVO vo, HttpServletRequest request,HttpSession session,HttpServletResponse response) throws Exception{
		
		String inputPass = vo.getPw();
		String pass = passEncoder.encode(inputPass);
		vo.setPw(pass);
		service.create_user(vo);
		

		return "redirect:/covid/login";
	}
	
	
	
	
	

	@RequestMapping(value="/idcheck", method = RequestMethod.POST)
	public @ResponseBody int postIdchek(HttpServletRequest request) throws Exception{
		
		
		String id = request.getParameter("id");
		UserVO idCheck = service.idcheck(id);
		
		int result = 0;
		
		
		if(idCheck != null) {
			result = 1;
		}
		
		
		return result;
		
	}
	
	
	
	
	
	@RequestMapping(value="/findid", method = RequestMethod.GET)
	public void getfindid(LoginDTO dto, Model model) throws Exception {
		
	
		
		
	
		
	}
	
	@RequestMapping(value="/findidresult", method = RequestMethod.POST)
	public void postfindid(LoginDTO dto, Model model) throws Exception {
		
		UserVO findid = service.findid(dto);
		
		if(findid != null) {
			model.addAttribute("findid",findid);
			System.out.println("�굹�샂");
		}
		
		
		
	
		
	}
	
	@RequestMapping(value="/findpw", method = RequestMethod.GET)
	public void getfindpw(LoginDTO dto, Model model) throws Exception {
			
	}
	
	@RequestMapping(value="/findpwresult", method = RequestMethod.POST)
	public void postfindpw(@RequestParam Map<String, String> map,UserVO vo, Model model) throws Exception {
		
		System.out.println("메일발송");
		
		String id = map.get("name");
		String findemail = map.get("email");
		
		System.out.println(id);
		System.out.println(findemail);
		
		
		String newpassword = RandomStringUtils.randomAlphanumeric(10);
		System.out.println(newpassword);
		String pass = passEncoder.encode(newpassword);
		
		
		Map hashmap = new HashMap();
		hashmap.put("id", id);
		hashmap.put("email", findemail);
		hashmap.put("pw", pass); 
       
		try { 
		if(pass != null) {
			
            
			service.emailsend(findemail,newpassword);
			
			
			service.findpassword(hashmap);
			
			
			
		} 
		
		else {
			
			 
			System.out.println("메일발송 실패");
		}

				

	} catch (MessagingException e) {
		e.printStackTrace();
		
	}
		
		
	}
	
	@RequestMapping(value="/newpassword", method = RequestMethod.POST)
	public String PostNewpassword(UserVO vo,@RequestParam("pw") String newpassword,HttpSession session,HttpServletResponse response, HttpServletRequest request) throws Exception{
		

		 
		
		String pass = passEncoder.encode(newpassword);
		System.out.println(pass);

			vo.setPw(pass);
			
			service.newpassword(vo);
			session.removeAttribute(SessionNames.LOGIN);
			session.invalidate();
			
			Cookie loginCookie = WebUtils.getCookie(request,SessionNames.LOGIN);
			if(loginCookie != null) {
				loginCookie.setPath("/");
				loginCookie.setMaxAge(0);
				
				response.addCookie(loginCookie);

				
				   

			}
	
			
			return "redirect:/";
		
	
		
	}
	
}
