package com.covid.domain;

import lombok.Data;

@Data
public class ApiDTO {
	String serviceKey;
	public String getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(String serviceKey) {
		this.serviceKey = serviceKey;
	}
	public String getStartCreateDt() {
		return startCreateDt;
	}
	public void setStartCreateDt(String startCreateDt) {
		this.startCreateDt = startCreateDt;
	}
	public String getEndCreateDt() {
		return endCreateDt;
	}
	public void setEndCreateDt(String endCreateDt) {
		this.endCreateDt = endCreateDt;
	}
	String startCreateDt;
	String endCreateDt;
	
}
